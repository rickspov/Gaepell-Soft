# 🚀 EvaaCRM - Despliegue con Release

## 📋 Instalación

1. **Ejecutar instalación:**
   ```bash
   ./install.sh
   ```

2. **Iniciar la aplicación:**
   ```bash
   ./start_eva_crm.sh
   ```

3. **Acceder a la aplicación:**
   ```
   https://grupogaepell.com/admin/
   ```

## 🔧 Comandos Útiles

- **Iniciar aplicación:** `./start_eva_crm.sh`
- **Crear backup:** `./backup_database.sh`
- **Ver logs:** `tail -f logs/evaa_crm.log`

## 📁 Estructura

- `evaa_crm_gaepell/` - Release de la aplicación
- `.env` - Variables de entorno
- `.htaccess` - Configuración de proxy reverso
- `start_eva_crm.sh` - Script de inicio
- `backup_database.sh` - Script de backup
- `install.sh` - Script de instalación

## 🗄️ Base de Datos

- **Usuario:** `eva_crm_user`
- **Base de datos:** `eva_crm_db`
- **Contraseña:** `EvaCrm2025!`
- **Host:** `localhost`
