#!/bin/bash

# 🚀 Script de instalación para /admin
# Uso: ./install.sh

set -e

echo "🚀 Iniciando instalación de EVA CRM en /admin..."

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que .env existe
if [ ! -f ".env" ]; then
    print_error "Archivo .env no encontrado. Por favor:"
    echo "1. Copia .env.example a .env"
    echo "2. Edita .env con tus credenciales"
    echo "3. Ejecuta este script nuevamente"
    exit 1
fi

# Cargar variables de entorno
print_status "📋 Cargando variables de entorno..."
source .env

# Instalar dependencias
print_status "📦 Instalando dependencias..."
mix deps.get

# Ejecutar migraciones
print_status "🗄️ Ejecutando migraciones de base de datos..."
mix ecto.migrate

# Compilar assets
print_status "🎨 Compilando assets..."
cd apps/evaa_crm_web_gaepell/assets

# Compilar CSS con Tailwind
npx tailwindcss -i css/app.css -o ../priv/static/assets/app.css --minify

# Compilar JS con esbuild
npx esbuild js/app.js --bundle --target=es2017 --outdir=../priv/static/assets --external:/fonts/* --external:/images/*

cd ../../

# Generar secret key base si no está configurado
if [ "$SECRET_KEY_BASE" = "tu_secret_key_aqui" ]; then
    print_warning "Generando nuevo SECRET_KEY_BASE..."
    NEW_SECRET=$(mix phx.gen.secret)
    sed -i "s/tu_secret_key_aqui/$NEW_SECRET/" .env
    export SECRET_KEY_BASE="$NEW_SECRET"
    print_success "SECRET_KEY_BASE generado y actualizado en .env"
fi

# Crear script de inicio
print_status "🔧 Creando script de inicio..."
cat > start_eva_crm.sh << 'SCRIPT_EOF'
#!/bin/bash
cd "$(dirname "$0")"
source .env
mix phx.server
SCRIPT_EOF

chmod +x start_eva_crm.sh

print_success "✅ Instalación completada!"
echo ""
echo "🚀 Para iniciar la aplicación:"
echo "   ./start_eva_crm.sh"
echo ""
echo "📱 Para acceder a la aplicación:"
echo "   https://grupo-gaepell.com/admin/"
echo ""
echo "📖 Ver ADMIN_DEPLOYMENT_GUIDE.md para más detalles"
