defmodule EvaaCrmWebGaepell.SessionHTML do
  use EvaaCrmWebGaepell, :html

  embed_templates "session_html/*"
end 