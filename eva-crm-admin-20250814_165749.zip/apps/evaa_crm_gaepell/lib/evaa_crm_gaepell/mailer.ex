defmodule EvaaCrmGaepell.Mailer do
  use Swoosh.Mailer, otp_app: :evaa_crm
end
