ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(EvaaCrm.Repo, :manual)
