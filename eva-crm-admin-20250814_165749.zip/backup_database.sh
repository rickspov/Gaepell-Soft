#!/bin/bash

# 💾 Script de backup de base de datos
# Uso: ./backup_database.sh

set -e

echo "💾 Creando backup de la base de datos..."

# Cargar variables de entorno
source .env

# Extraer información de la base de datos
DB_NAME=$(echo $DATABASE_URL | sed 's/.*\///')
DB_USER=$(echo $DATABASE_URL | sed 's/.*:\/\/\([^:]*\):.*/\1/')
DB_HOST=$(echo $DATABASE_URL | sed 's/.*@\([^:]*\):.*/\1/')

# Crear backup
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="database_backup_$TIMESTAMP.sql"

echo "📦 Creando backup: $BACKUP_FILE"
mysqldump -h $DB_HOST -u $DB_USER -p $DB_NAME > $BACKUP_FILE

echo "✅ Backup creado exitosamente: $BACKUP_FILE"
echo "📏 Tamaño: $(du -h $BACKUP_FILE | cut -f1)"
