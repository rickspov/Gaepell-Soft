#!/bin/bash
cd "$(dirname "$0")"

# Cargar variables de entorno
source .env

# Generar secret key base si no existe
if [ "$SECRET_KEY_BASE" = "tu_secret_key_aqui" ]; then
    echo "🔑 Generando SECRET_KEY_BASE..."
    NEW_SECRET=$(./evaa_crm_gaepell/bin/evaa_crm_gaepell eval "IO.puts(Base.encode64(:crypto.strong_rand_bytes(64)))")
    sed -i "s/tu_secret_key_aqui/$NEW_SECRET/" .env
    export SECRET_KEY_BASE="$NEW_SECRET"
    echo "✅ SECRET_KEY_BASE generado y actualizado en .env"
fi

# Ejecutar migraciones
echo "🗄️ Ejecutando migraciones..."
./evaa_crm_gaepell/bin/evaa_crm_gaepell eval "EvaaCrmGaepell.Release.migrate"

# Iniciar la aplicación
echo "🚀 Iniciando EvaaCRM..."
./evaa_crm_gaepell/bin/evaa_crm_gaepell start
