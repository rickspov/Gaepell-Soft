#!/bin/bash

# 🚀 Script de instalación EvaaCRM con Release
echo "🚀 Iniciando instalación de EvaaCRM con Release..."

# Verificar que estamos en el directorio correcto
if [ ! -f "start_eva_crm.sh" ]; then
    echo "❌ No se encontró start_eva_crm.sh. Asegúrate de estar en el directorio correcto."
    exit 1
fi

# Dar permisos de ejecución
chmod +x start_eva_crm.sh
chmod +x backup_database.sh
chmod +x evaa_crm_gaepell/bin/evaa_crm_gaepell

# Crear directorio de logs
mkdir -p logs

# Ejecutar migraciones y iniciar
echo "🗄️ Ejecutando migraciones..."
./evaa_crm_gaepell/bin/evaa_crm_gaepell eval "EvaaCrmGaepell.Release.migrate"

echo "✅ Instalación completada!"
echo ""
echo "🚀 Para iniciar la aplicación:"
echo "   ./start_eva_crm.sh"
echo ""
echo "📱 Para acceder a la aplicación:"
echo "   https://grupogaepell.com/admin/"
echo ""
echo "💾 Para crear backup de la base de datos:"
echo "   ./backup_database.sh"
